from mcmetrics.models.ols import OLS
from mcmetrics.models.wls import WLS
from mcmetrics.models.gls import GLS

__all__ = ["OLS", "WLS", "GLS"]
